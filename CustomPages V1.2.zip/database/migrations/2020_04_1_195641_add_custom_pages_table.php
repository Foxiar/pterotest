<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddCustomPagesTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('custompages', function (Blueprint $table) {
            $table->increments('id');
            $table->string('route');
            $table->string('title');
            $table->string('description');
            $table->string('keywords');
            $table->string('content', 5000000);
            $table->string('status');
            $table->string('viewable');
            $table->string('author_show');
            $table->string('author_name');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::dropIfExists('custompages');
    }
}
