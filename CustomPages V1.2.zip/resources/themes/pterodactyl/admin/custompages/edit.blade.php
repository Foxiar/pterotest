{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.admin')

@section('title')
    Edit Custom Page's
@endsection

@section('content-header')
<h1>Custom Pages<small>Here you can sedit all your custom pages.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.custompages.index') }}">Home</a></li>
        <li class="active">Custom Pages</li>
    </ol>
@endsection

@section('content')
@if(Auth::user()->root_admin)
	<div class="row">
        <div class="col-xs-12">
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3 class="box-title">Page - Editor</h3>
                    <div class="box-tools">
                        <a href="{{ route('admin.custompages.index') }}" class="btn btn-sm btn-primary">Go Back</a>
                    </div>
                </div>
                <form method="post" action="{{ route('admin.custompages.update', $pages->id) }}">
                    <div class="box-body">
                        <div class="form-group">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" name="title" id="title" class="form-control" value="{{ $pages->title }}" />
                        </div>
                        <div class="form-group">
                            <label for="body" class="form-label"><A>Content</A></label>
                            <textarea name="content" id="content" rows="4" class="form-control">{{ $pages->content }}</textarea>
                        </div>
            </div>
        </div>
        <div class="box box-danger">
        <div class="box-header with-border">
        <h3 class="box-title">SEO Page - Settings</h3>
        </div>
        <div class="box-body">
                        <div class="form-group">
                            <label for="keywords" class="form-label">Keywords</label>
                            <input type="text" name="keywords" id="keywords" class="form-control" value="{{ $pages->keywords }}" />
                        </div>
                        <div class="form-group">
                            <label for="description" class="form-label"><A>Description</A></label>
                            <textarea name="description" id="description" rows="3" class="form-control">{{ $pages->description }}</textarea>
                        </div>
                    </div>
                    </div>
        <div class="box box-danger">
        <div class="box-header with-border">
        <h3 class="box-title">Page - Settings</h3>
        </div>
        <div class="box-body">
                        <div class="form-group">
                            <label for="title" class="form-label">Page Route:</label>
                            <input type="text" name="route" id="route" class="form-control" value="{{ $pages->route }}" />
                            <p style="margin-top: 0.5%;">Don't use <code>/, #</code> because then the link won't work.</p>
                            <label for="title" class="form-label">Status:</label>
                            <select name="status" class="form-control">
                            @if($pages->status == 'Published')
                            <option selected value="Published">Published</option>
                            @else
                            <option value="Published">Published</option>
                            @endif
                            @if($pages->status == 'Hidden')
                            <option selected value="Hidden">Hidden</option>
                            @else
                            <option value="Hidden">Hidden</option>
                            @endif
                            </select><br>
                            <label for="title" class="form-label">Viewable By:</label>
                            <select name="viewable" class="form-control">
                            @if($pages->viewable == 'Everyone')
                            <option selected value="Everyone">Everyone</option>
                            @else
                            <option value="Everyone">Everyone</option>
                            @endif
                            @if($pages->viewable == 'Admin')
                            <option selected value="Admin">Admin</option>
                            @else
                            <option value="Admin">Admin</option>
                            @endif
                            </select>
                            </div>
                    </div>
                    </div>

                    </div>
    </div>
    {!! csrf_field() !!}
                        <button style="width: 100%;" class="btn btn-success pull-left" type="submit">Save</button><br><br>
                </form>
                </div>
                </div>
@endif
@if(!Auth::user()->root_admin)
<div class="box-body" style="padding-left: 30px; background-color: rgba(255, 56, 56, 0.50) !important; border-radius: 20px; color: #d4d4d4 !important; padding-right: 30px; padding-bottom: 30px; margin-top: 5%;">
                    <h2 style="font-size: 22px; font-weight: 500;"><i class="fas fa-exclamation-triangle" style="color: rgb(255, 0, 0) !important;" aria-hidden="true"></i> Knowledgebase</h2>
                    <p>You can't use this page you aren't an admin user.</p>
                </div></div>
    @endif
@endsection

@section('footer-scripts')
    @parent
    <script src="//cdn.ckeditor.com/4.14.0/full/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'content' );
    </script>
    <script>
        $('tr.server-description').on('mouseenter mouseleave', function (event) {
            $(this).prev('tr').css({
                'background-color': (event.type === 'mouseenter') ? '#f5f5f5' : '',
            });
        });
    </script>
    {!! Theme::js('js/frontend/serverlist.js') !!}	
@endsection
