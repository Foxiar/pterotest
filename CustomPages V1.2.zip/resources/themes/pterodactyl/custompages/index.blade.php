{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
@foreach($pages as $page)
{{ $page->title }}
@endforeach
@endsection

@section('content-header')
<meta name="title" content="{{ $page->title }}">
<meta name="description" content="{{ $page->description }}">
<meta name="keywords" content="{{ $page->keywords}}">
<meta name="author" content="{{ $page->author_name }}">
@endsection

@section('content')
@foreach($pages as $page)
@if($page->viewable == 'Admin')
@if(Auth::user()->root_admin)
@if($page->status == 'Published')
{!! $page->content !!}
@elseif($page->status == 'Hidden')
    <div class="box">
        <div class="box-header">
            <br><h2 style="font-size: 22px; font-weight: 500;"><i class="fa fa-exclamation-triangle" style="color: rgb(255, 0, 0) !important;" aria-hidden="true"></i> {{ $page->title }}</h2>
            <p>This page is not published yet.</p>
        </div>
    </div>
    @endif
@endif
@else
@if($page->viewable == 'Everyone')
@if($page->status == 'Published')
{!! $page->content !!}
@elseif($page->status == 'Hidden')
    <div class="box">
        <div class="box-header">
            <br><h2 style="font-size: 22px; font-weight: 500;"><i class="fa fa-exclamation-triangle" style="color: rgb(255, 0, 0) !important;" aria-hidden="true"></i> {{ $page->title }}</h2>
            <p>This page is not published yet.</p>
        </div>
    </div>
@endif
@else
<div class="box">
        <div class="box-header">
            <br><h2 style="font-size: 22px; font-weight: 500;"><i class="fa fa-exclamation-triangle" style="color: rgb(255, 0, 0) !important;" aria-hidden="true"></i> {{ $page->title }}</h2>
            <p>This page is not for everyone yet.</p>
        </div>
    </div>
@endif
@endif
@endforeach
@endsection

@section('footer-scripts')
    @parent
@endsection
