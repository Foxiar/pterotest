<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Traits\Controllers\JavascriptInjection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CustomPagesController extends Controller
{
    
    use JavascriptInjection;
    private $alert;
    protected $cache;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->middleware("auth");
        $this->alert = $alert;
    }

    public function index(Request $request): View
    {
        $pages = DB::table('custompages')->paginate(10);

        return view('admin.custompages.index', [
            'pages' => $pages,
        ]);
    }
    
    public function new(Request $request): View
    {
        $pages = DB::table('custompages')->get();

        return view('admin.custompages.new', [
            'pages' => $pages
        ]);
    }

    public function delete(Request $request, $id)
    {
        $id = (int) $id;
        
        DB::table('custompages')->where('id', '=', $id)->delete();
        $this->alert->success('You have successfully deleted the page')->flash();
	    return redirect()->route('admin.custompages.index');
    }
    

    public function update(Request $request, $id)
    {
        $id = (int) $id;

        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
            'keywords' => 'required',
            'content' => 'required',
            'route' => 'required',
            'viewable' => 'required',
            'status' => 'required'
        ]);

        $title = trim(strip_tags($request->input('title')));
        $description = trim(strip_tags($request->input('description')));
        $keywords = trim(strip_tags($request->input('keywords')));
        $content = trim($request->input('content'));
        $viewable = trim($request->input('viewable'));
        $author_show = trim($request->input('author_show'));
        $status = trim($request->input('status'));
        $route = trim(str_replace(' ', '_', str_replace('/', '-', $request->input('route'))));

        DB::table('custompages')->where('id', '=', $id)->update([
            'route' => $route,
            'title' => $title,
            'description' => $description,
            'keywords' => $keywords,
            'author_name' => $request->user()->username,
            'author_show' => '-',
            'status' => $status,
            'viewable' => $viewable,
            'content' => $content,
            'updated_at' => \Carbon\Carbon::now()
        ]);
        $this->alert->success('You have successfully edited this page')->flash();

        return redirect()->route('admin.custompages.index');
    }

    public function create(Request $request)
    {
        $this->validate($request, [
            'title' => 'required',
            'description' => 'required',
            'keywords' => 'required',
            'content' => 'required',
            'route' => 'required',
            'viewable' => 'required',
            'status' => 'required'
        ]);

        $title = trim(strip_tags($request->input('title')));
        $description = trim(strip_tags($request->input('description')));
        $keywords = trim(strip_tags($request->input('keywords')));
        $content = trim($request->input('content'));
        $author_show = trim($request->input('author_show'));
        $status = trim($request->input('status'));
        $viewable = trim($request->input('viewable'));
        $route = trim(str_replace(' ', '_', str_replace('/', '-', $request->input('route'))));

        DB::table('custompages')->insert([
            'route' => $route,
            'title' => $title,
            'description' => $description,
            'keywords' => $keywords,
            'author_name' => $request->user()->username,
            'author_show' => '-',
            'status' => $status,
            'viewable' => $viewable,           
            'content' => $content,
            'updated_at' => \Carbon\Carbon::now(),
            'created_at' => \Carbon\Carbon::now(),
        ]);
        $this->alert->success('You have successfully creadted the page')->flash();

        return redirect()->route('admin.custompages.index');
    }

    public function edit(Request $request, $id)
    {
        $id = (int) $id;

        $pages = DB::table('custompages')->where('id', '=', $id)->get();

        if (count($pages) < 1) {
            return redirect()->route('admin.custompages.edit');
        }

        return view('admin.custompages.edit', [
            'pages' => $pages[0],
        ]);

    }
}