<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Traits\Controllers\JavascriptInjection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CustomPagesController extends Controller
{
    
    private $alert;
    protected $cache;

    public function __construct(AlertsMessageBag $alert)
    {
        $this->middleware("auth");
        $this->alert = $alert;
    }

    public function index(Request $request, $id)
    {
        $pages = DB::table('custompages')->where('route', '=', $id)->get();

        return view('custompages.index', [
            'pages' => $pages,
        ]);
    }
}



